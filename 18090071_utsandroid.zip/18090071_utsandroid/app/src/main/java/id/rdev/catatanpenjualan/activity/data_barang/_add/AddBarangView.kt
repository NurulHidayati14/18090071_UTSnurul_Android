package id.rdev.catatanpenjualan.activity.data_barang._add

interface AddBarangView {
    fun onSuccessAddBarang(msg: String?)
    fun onErrorAddBarang(msg: String?)
}